#!/bin/bash
# Created by เฮียเบิร์ด.com
curl เฮียเบิร์ด.com/index.html
echo ""
